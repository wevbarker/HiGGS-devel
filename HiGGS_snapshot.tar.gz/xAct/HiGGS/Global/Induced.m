(* this file defines the induced metric *)

(* firstly define the parallel eta metric, recall that this has the same meaning as PPara, and so we may wish to merge the quantities at some point *)
GPSymb="\!\(\*SuperscriptBox[OverscriptBox[\(\[Eta]\), \(^\)], \(\[DoubleVerticalBar]\)]\)";

(*
Quiet@UndefTensor@PerturbationGP;  (*we find using VisitorsOf that the calling of xPert automatically assigns PerturbationG, so we need to remove it first*)
Quiet@UndefMetric@GP;
*)
Catch@Quiet@DefMetric[1,GP[-a,-b],CDP,{"~","error"},InducedFrom->{G,V},PrintAs->GPSymb];

(* a rule which switches the induce metric for FoliG within ToNewCanonical *)

Print@"try rule";
Print@xAct`HiGGS`Private`GPToFoliG;
Print@Global`GPToFoliG;
xAct`HiGGS`Private`GPToFoliG=MakeRule[{GP[-a,-b],G[-a,-b]-V[-a]V[-b]},MetricOn->All,ContractMetrics->True];
Print@"made rule";

(* generate projection rules over the Lorentzian derivative for all the most imporant Nester form tensors *)

Print@"4";
xAct`HiGGS`Private`ProjectLorentzGaugeCovDRule={};
Print@"5";
xAct`HiGGS`Private`ExpandLorentzGaugeCovDProjectionRule={};
Print@"6";
xAct`HiGGS`Private`ProjectGaugeCovDRule={};
Print@"6.5";

xAct`HiGGS`Private`PrecomputeDerivativeProjections[];
Print@"7";

(* another miscellaneous rule whose counterpart we need to form using induced structure *)

Print@"try anothe";
xAct`HiGGS`Private`ProjectedLorentzGaugeCovDVExpand=MakeRule[{Evaluate@(ProjectorGP@(LorentzGaugeCovD[-m]@V[-j])),Evaluate[Symmetrize[ProjectorGP@(LorentzGaugeCovD[-m]@V[-j]),{-m,-j}]-(1/2)V[-i]TP[i,-m,-j]/.PADMActivate]},MetricOn->All,ContractMetrics->True];
Print@"madee";
